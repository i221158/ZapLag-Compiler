import java.util.*;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;

class SymbolEntry {
    String type;
    String scope; // "akela" for local, "sabka" for global
    String value;

    public SymbolEntry(String type, String scope, String value) {
        this.type = type;
        this.scope = scope;
        this.value = value;
    }
}

class SymbolTable {
    private Map<String, SymbolEntry> table;

    public SymbolTable() {
        this.table = new LinkedHashMap<>(); // Maintain insertion order
    }

    // Add a new variable to the symbol table
    public void addSymbol(String identifier, String type, String scope, String value) {
        if (table.containsKey(identifier) && table.get(identifier).scope.equals(scope)) {
            System.out.println("Error: Variable '" + identifier + "' is already declared in " + scope + " scope.");
            return;
        }
        table.put(identifier, new SymbolEntry(type, scope, value));
    }


    // Get the type of a variable
    public String getType(String identifier) {
        return table.containsKey(identifier) ? table.get(identifier).type : "Undefined";
    }

    // Get the scope of a variable
    public String getScope(String identifier) {
        return table.containsKey(identifier) ? table.get(identifier).scope : "Undefined";
    }

    // Get the value of a variable
    public String getValue(String identifier) {
        return table.containsKey(identifier) ? table.get(identifier).value : "Undefined";
    }

    // Print the symbol table
    public void printSymbolTable() {
        System.out.println("\nSymbol Table:");
        System.out.println("+----------------+--------------+---------+--------+");
        System.out.println("| Identifier     | Type         | Scope   | Value  |");
        System.out.println("+----------------+--------------+---------+--------+");
        for (Map.Entry<String, SymbolEntry> entry : table.entrySet()) {
            SymbolEntry symbol = entry.getValue();
            System.out.printf("| %-14s | %-12s | %-7s | %-6s |\n",
                    entry.getKey(), symbol.type, symbol.scope, symbol.value);
        }
        System.out.println("+----------------+--------------+---------+--------+");
    }
}



class NFA {
   NFAState startState;
   Set<NFAState> finalStates;
   int stateCounter;

   public NFA() {
       this.finalStates = new HashSet<>();
       this.stateCounter = 0;
   }

   public NFA constructFromRegex(String regex) {
       Stack<NFA> stack = new Stack<>();

       int i = 0;
       while (i < regex.length()) {
           char ch = regex.charAt(i);

           if (ch == '[') {
               int endIndex = regex.indexOf(']', i);
               if (endIndex == -1) throw new IllegalArgumentException("Invalid regex: missing ']'");
               String range = regex.substring(i + 1, endIndex);
               stack.push(createRangeNFA(range));
               i = endIndex;
           } else if (ch == '*') {
               stack.push(kleeneStar(stack.pop())); // Apply Kleene star correctly
           } else if (ch == '+') {
               stack.push(oneOrMore(stack.pop())); // Apply one or more (+)
           } else if (ch == '?') {
               stack.push(optional(stack.pop())); // Apply optional (?)
           } else if (ch == '.') {
               stack.push(createBasicNFA('.')); // Decimal point handling
           } else if (ch == '{') { // Handle {1,5} manually
               int closeIndex = regex.indexOf('}', i);
               if (closeIndex == -1) throw new IllegalArgumentException("Invalid regex: missing '}'");
               String[] range = regex.substring(i + 1, closeIndex).split(",");
               int min = Integer.parseInt(range[0]);
               int max = Integer.parseInt(range[1]);
               NFA repeatedNFA = repeat(stack.pop(), min, max);
               stack.push(repeatedNFA);
               i = closeIndex;
           } else {
               stack.push(createBasicNFA(ch));
               if (stack.size() > 1) {
                   NFA nfa2 = stack.pop();
                   NFA nfa1 = stack.pop();
                   stack.push(concatenate(nfa1, nfa2));
               }
           }
           i++;
       }

       return stack.pop();
   }

   private NFA createRangeNFA(String range) {
       NFAState start = new NFAState(stateCounter++);
       NFAState end = new NFAState(stateCounter++);
       end.isFinal = true;

       for (char c = range.charAt(0); c <= range.charAt(2); c++) {
           start.addTransition(c, end);
       }

       NFA nfa = new NFA();
       nfa.startState = start;
       nfa.finalStates.add(end);
       return nfa;
   }

   private NFA createBasicNFA(char symbol) {
       NFAState start = new NFAState(stateCounter++);
       NFAState end = new NFAState(stateCounter++);
       start.addTransition(symbol, end);
       end.isFinal = true;

       NFA nfa = new NFA();
       nfa.startState = start;
       nfa.finalStates.add(end);
       return nfa;
   }

   private NFA concatenate(NFA nfa1, NFA nfa2) {
       for (NFAState finalState : nfa1.finalStates) {
           finalState.addTransition('ε', nfa2.startState);
           finalState.isFinal = false;
       }
       nfa1.finalStates = nfa2.finalStates;
       return nfa1;
   }

   private NFA kleeneStar(NFA nfa) {
       NFAState start = new NFAState(stateCounter++);
       NFAState loop = new NFAState(stateCounter++);
       start.addTransition('ε', nfa.startState);
       start.addTransition('ε', loop);

       for (NFAState finalState : nfa.finalStates) {
           for (char c : nfa.startState.transitions.keySet()) {
               finalState.addTransition(c, finalState); // Self-loop on all valid chars
           }
           finalState.addTransition('ε', loop);
           finalState.isFinal = true;
       }

       NFA newNFA = new NFA();
       newNFA.startState = start;
       newNFA.finalStates.add(loop);
       return newNFA;
   }

   private NFA repeat(NFA nfa, int min, int max) {
       NFAState start = new NFAState(stateCounter++);
       NFAState last = start;

       for (int i = 0; i < min; i++) {
           NFA copy = copyNFA(nfa);
           last.addTransition('ε', copy.startState);
           last = getFinalState(copy);
       }

       for (int i = min; i < max; i++) {
           NFA copy = copyNFA(nfa);
           last.addTransition('ε', copy.startState);
           last.addTransition('ε', getFinalState(copy));
           last = getFinalState(copy);
       }

       last.isFinal = true;

       NFA repeatedNFA = new NFA();
       repeatedNFA.startState = start;
       repeatedNFA.finalStates.add(last);
       return repeatedNFA;
   }

   private NFA optional(NFA nfa) {
       NFAState start = new NFAState(stateCounter++);
       start.addTransition('ε', nfa.startState);
       start.isFinal = true;

       NFA newNFA = new NFA();
       newNFA.startState = start;
       newNFA.finalStates.addAll(nfa.finalStates);
       return newNFA;
   }

   private NFA oneOrMore(NFA nfa) {
       NFAState start = new NFAState(stateCounter++);
       NFAState last = getFinalState(nfa);

       start.addTransition('ε', nfa.startState);
       last.addTransition('ε', start);

       NFA newNFA = new NFA();
       newNFA.startState = start;
       newNFA.finalStates.add(last);
       return newNFA;
   }


   private NFA copyNFA(NFA original) {
       Map<NFAState, NFAState> stateMap = new HashMap<>();
       Queue<NFAState> queue = new LinkedList<>();
       queue.add(original.startState);

       while (!queue.isEmpty()) {
           NFAState oldState = queue.poll();
           NFAState newState = stateMap.computeIfAbsent(oldState, s -> new NFAState(stateCounter++));
           newState.isFinal = oldState.isFinal;

           for (Map.Entry<Character, List<NFAState>> entry : oldState.transitions.entrySet()) {
               for (NFAState oldTarget : entry.getValue()) {
                   NFAState newTarget = stateMap.computeIfAbsent(oldTarget, s -> new NFAState(stateCounter++));
                   newState.addTransition(entry.getKey(), newTarget);
                   queue.add(oldTarget);
               }
           }
       }

       NFA copy = new NFA();
       copy.startState = stateMap.get(original.startState);
       copy.finalStates = new HashSet<>(stateMap.values());
       return copy;
   }
   private NFAState getFinalState(NFA nfa) {
       return nfa.finalStates.iterator().next();
   }

   public void printNFA() {
       Set<NFAState> visited = new HashSet<>();
       Queue<NFAState> queue = new LinkedList<>();
       queue.add(startState);
       visited.add(startState);

       while (!queue.isEmpty()) {
           NFAState current = queue.poll();
           System.out.println("State " + current.id + " (Final: " + current.isFinal + ")");
           for (Map.Entry<Character, List<NFAState>> entry : current.transitions.entrySet()) {
               for (NFAState state : entry.getValue()) {
                   System.out.println("  " + current.id + " -- " + entry.getKey() + " --> " + state.id);
                   if (!visited.contains(state)) {
                       queue.add(state);
                       visited.add(state);
                   }
               }
           }
       }
   }
}

class NFAState {
   int id;
   Map<Character, List<NFAState>> transitions;
   boolean isFinal;

   public NFAState(int id) {
       this.id = id;
       this.transitions = new HashMap<>();
       this.isFinal = false;
   }

   public void addTransition(char symbol, NFAState state) {
       transitions.computeIfAbsent(symbol, k -> new ArrayList<>()).add(state);
   }
}
class LexicalAnalyzer {
    // Token types
    public enum TokenType {
        IDENTIFIER, INTEGER, DECIMAL, CHARACTER, KEYWORD, OPERATOR,
        SINGLE_LINE_COMMENT, MULTILINE_COMMENT, STRING, BOOLEAN, UNKNOWN, ERROR,
        CONSTANT // Added CONSTANT to TokenType
    }

    // Token class to store type, value, and line number
    public static class Token {
        public TokenType type;
        public String value;
        public int lineNumber;

        public Token(TokenType type, String value, int lineNumber) {
            this.type = type;
            this.value = value;
            this.lineNumber = lineNumber;
        }

        @Override
        public String toString() {
            return String.format("Token [%s, %s, Line %d]", type, value, lineNumber);
        }
    }

    // Constants
    private static final Set<String> CONSTANTS = new HashSet<>(Arrays.asList(
            "sabka", "akela" // Added "sabka" and "akela" as constants
    ));

    // Data types
    private static final Set<String> DATA_TYPES = new HashSet<>(Arrays.asList(
            "mint", "drink", "bubble", "cherry"
    ));

    // Keywords
    private static final Set<String> KEYWORDS = new HashSet<>(Arrays.asList(
            "mint", "drink", "bubble", "cherry", "$", "!$", "sabka", "akela"
    ));

    // Operators
    private static final Set<Character> OPERATORS = new HashSet<>(Arrays.asList(
            '=', '+', '-', '*', '/', '%', '^', ';'
    ));

    private static final SymbolTable symbolTable = new SymbolTable();

    // Tokenize input source code
    public static List<Token> tokenize(String sourceCode) {
        List<Token> tokens = new ArrayList<>();
        int lineNumber = 1;
        int index = 0;
        String scope = "sabka"; // Default scope is global

        while (index < sourceCode.length()) {
            char currentChar = sourceCode.charAt(index);

            // Skip whitespace
            if (Character.isWhitespace(currentChar)) {
                if (currentChar == '\n') lineNumber++;
                index++;
                continue;
            }

            // Check for constants (sabka and akela)
            if (index + 4 < sourceCode.length() && CONSTANTS.contains(sourceCode.substring(index, index + 5))) {
                String constant = sourceCode.substring(index, index + 5);
                tokens.add(new Token(TokenType.CONSTANT, constant, lineNumber));
                scope = constant; // Update the scope
                index += 5;
                continue;
            }

            // Identifiers and Keywords
            if (Character.isLowerCase(currentChar)) {
                int start = index;
                while (index < sourceCode.length() &&
                        (Character.isLowerCase(sourceCode.charAt(index)) || sourceCode.charAt(index) == '_')) {
                    index++;
                }
                String value = sourceCode.substring(start, index);

                if (DATA_TYPES.contains(value)) { // Found a type
                    tokens.add(new Token(TokenType.KEYWORD, value, lineNumber));

                    // Look ahead for a variable name
                    while (index < sourceCode.length() && Character.isWhitespace(sourceCode.charAt(index))) {
                        index++; // Skip spaces
                    }

                    if (index < sourceCode.length() && Character.isLowerCase(sourceCode.charAt(index))) {
                        int varStart = index;
                        while (index < sourceCode.length() &&
                                (Character.isLowerCase(sourceCode.charAt(index)) || sourceCode.charAt(index) == '_')) {
                            index++;
                        }
                        String identifier = sourceCode.substring(varStart, index);
                        tokens.add(new Token(TokenType.IDENTIFIER, identifier, lineNumber));

                        // Look ahead for assignment (=) to get the value
                        String assignedValue = "null";
                        while (index < sourceCode.length() && Character.isWhitespace(sourceCode.charAt(index))) {
                            index++;
                        }
                        if (index < sourceCode.length() && sourceCode.charAt(index) == '=') {
                            index++; // Skip '='
                            while (index < sourceCode.length() && Character.isWhitespace(sourceCode.charAt(index))) {
                                index++;
                            }

                            int valueStart = index;
                            while (index < sourceCode.length() &&
                                    !Character.isWhitespace(sourceCode.charAt(index)) &&
                                    sourceCode.charAt(index) != ';') {
                                index++;
                            }
                            assignedValue = sourceCode.substring(valueStart, index);
                        }

                        // Add to Symbol Table with Scope and Value
                        symbolTable.addSymbol(identifier, value, scope, assignedValue);
                    }
                } else {
                    tokens.add(new Token(KEYWORDS.contains(value) ? TokenType.KEYWORD : TokenType.IDENTIFIER, value, lineNumber));
                }
                continue;
            }

            // Numbers (Integer or Decimal)
            if (Character.isDigit(currentChar)) {
                int start = index;
                boolean isDecimal = false;
                while (index < sourceCode.length() &&
                        (Character.isDigit(sourceCode.charAt(index)) || sourceCode.charAt(index) == '.')) {
                    if (sourceCode.charAt(index) == '.') {
                        if (isDecimal) {
                            System.out.println("Error: Invalid number format at line " + lineNumber);
                            tokens.add(new Token(TokenType.ERROR, sourceCode.substring(start, index + 1), lineNumber));
                            break;
                        }
                        isDecimal = true;
                    }
                    index++;
                }
                String value = sourceCode.substring(start, index);
                tokens.add(new Token(isDecimal ? TokenType.DECIMAL : TokenType.INTEGER, value, lineNumber));
                continue;
            }

            // Characters
            if (currentChar == '<') {
                if (index + 2 < sourceCode.length() && sourceCode.charAt(index + 2) == '>') {
                    tokens.add(new Token(TokenType.CHARACTER, sourceCode.substring(index, index + 3), lineNumber));
                    index += 3;
                    continue;
                }
            }

            // Strings
            if (currentChar == '"') {
                int start = index++;
                while (index < sourceCode.length() && sourceCode.charAt(index) != '"') {
                    index++;
                }
                if (index < sourceCode.length()) index++; // Include closing quote
                tokens.add(new Token(TokenType.STRING, sourceCode.substring(start, index), lineNumber));
                continue;
            }

            // Operators
            if (OPERATORS.contains(currentChar)) {
                tokens.add(new Token(TokenType.OPERATOR, Character.toString(currentChar), lineNumber));
                index++;
                continue;
            }

            // Single-line comment
            if (currentChar == '#' && index + 1 < sourceCode.length() && sourceCode.charAt(index + 1) != '*') {
                int start = index;
                while (index < sourceCode.length() && sourceCode.charAt(index) != '\n') {
                    index++;
                }
                tokens.add(new Token(TokenType.SINGLE_LINE_COMMENT, sourceCode.substring(start, index), lineNumber));
                continue;
            }

            // Multi-line comment
            if (currentChar == '#' && index + 1 < sourceCode.length() && sourceCode.charAt(index + 1) == '*') {
                int start = index;
                index += 2;
                while (index + 1 < sourceCode.length() && !(sourceCode.charAt(index) == '*' && sourceCode.charAt(index + 1) == '#')) {
                    if (sourceCode.charAt(index) == '\n') lineNumber++;
                    index++;
                }
                if (index + 1 < sourceCode.length()) index += 2;
                tokens.add(new Token(TokenType.MULTILINE_COMMENT, sourceCode.substring(start, index), lineNumber));
                continue;
            }

            // Unknown token
            System.out.println("Error: Unrecognized token '" + currentChar + "' at line " + lineNumber);
            tokens.add(new Token(TokenType.UNKNOWN, Character.toString(currentChar), lineNumber));
            index++;
        }

        return tokens;
    }

    public void printSymbolTable() {
        symbolTable.printSymbolTable();
    }
}
class DFA {
    DFAState startState;
    Set<DFAState> states;

    public DFA() {
        this.states = new HashSet<>();
    }

    public DFA constructFromNFA(NFA nfa) {
        Map<Set<NFAState>, DFAState> dfaStateMap = new HashMap<>();
        Queue<Set<NFAState>> queue = new LinkedList<>();

        // Step 1: Compute the ε-closure of the start state
        Set<NFAState> startClosure = epsilonClosure(Collections.singleton(nfa.startState));
        DFAState dfaStart = new DFAState(startClosure);
        dfaStateMap.put(startClosure, dfaStart);
        queue.add(startClosure);

        this.startState = dfaStart;
        this.states.add(dfaStart);

        // Step 2: Process each DFA state
        while (!queue.isEmpty()) {
            Set<NFAState> currentSet = queue.poll();
            DFAState currentDFAState = dfaStateMap.get(currentSet);

            // Process all possible input symbols
            Set<Character> alphabet = getAlphabet(nfa);
            for (char symbol : alphabet) {
                Set<NFAState> newStateSet = move(currentSet, symbol);
                newStateSet = epsilonClosure(newStateSet);

                if (!newStateSet.isEmpty()) {
                    DFAState newDFAState = dfaStateMap.get(newStateSet);
                    if (newDFAState == null) {
                        newDFAState = new DFAState(newStateSet);
                        dfaStateMap.put(newStateSet, newDFAState);
                        queue.add(newStateSet);
                        this.states.add(newDFAState);
                    }
                    currentDFAState.addTransition(symbol, newDFAState);
                }
            }
        }
        return this;
    }

    private Set<NFAState> epsilonClosure(Set<NFAState> states) {
        Set<NFAState> closure = new HashSet<>(states);
        Stack<NFAState> stack = new Stack<>();
        stack.addAll(states);

        while (!stack.isEmpty()) {
            NFAState state = stack.pop();
            List<NFAState> epsilonTransitions = state.transitions.getOrDefault('ε', new ArrayList<>());

            for (NFAState nextState : epsilonTransitions) {
                if (!closure.contains(nextState)) {
                    closure.add(nextState);
                    stack.push(nextState);
                }
            }
        }
        return closure;
    }

    private Set<NFAState> move(Set<NFAState> states, char symbol) {
        Set<NFAState> result = new HashSet<>();
        for (NFAState state : states) {
            List<NFAState> transitions = state.transitions.getOrDefault(symbol, new ArrayList<>());
            result.addAll(transitions);
        }
        return result;
    }

    private Set<Character> getAlphabet(NFA nfa) {
        Set<Character> alphabet = new HashSet<>();
        Queue<NFAState> queue = new LinkedList<>();
        Set<NFAState> visited = new HashSet<>();

        queue.add(nfa.startState);
        visited.add(nfa.startState);

        while (!queue.isEmpty()) {
            NFAState state = queue.poll();
            for (Character symbol : state.transitions.keySet()) {
                if (symbol != 'ε') {
                    alphabet.add(symbol);
                }
                for (NFAState nextState : state.transitions.get(symbol)) {
                    if (!visited.contains(nextState)) {
                        visited.add(nextState);
                        queue.add(nextState);
                    }
                }
            }
        }
        return alphabet;
    }

    public void printDFA() {
        System.out.println("\nDFA States and Transitions:");
        for (DFAState state : states) {
            System.out.print("DFA State " + state.id + " (Final: " + state.isFinal + ") -> ");
            for (Map.Entry<Character, DFAState> entry : state.transitions.entrySet()) {
                System.out.print(" [" + entry.getKey() + " -> " + entry.getValue().id + "] ");
            }
            System.out.println();
        }
    }
}

 class DFAState {
    static int count = 0;
    int id;
    Set<NFAState> nfaStates;
    Map<Character, DFAState> transitions;
    boolean isFinal;

    public DFAState(Set<NFAState> nfaStates) {
        this.id = count++;
        this.nfaStates = nfaStates;
        this.transitions = new HashMap<>();
        this.isFinal = nfaStates.stream().anyMatch(s -> s.isFinal);
    }

    public void addTransition(char symbol, DFAState state) {
        transitions.put(symbol, state);
    }
    
    }

    public class Processor {
    
        // Function to read a .mylanguage file and tokenize it
        public static void processFile(String filePath) {
            File file = new File(filePath);
            
            // Check if file exists
            if (!file.exists() || !filePath.endsWith("sample.zaplag")) {
                System.out.println(" Error: File not found or incorrect format. Please provide a .mylanguage file.");
                return;
            }
    
            StringBuilder sourceCode = new StringBuilder();
            
            // Read file contents
            try (BufferedReader br = new BufferedReader(new FileReader(file))) {
                String line;
                while ((line = br.readLine()) != null) {
                    sourceCode.append(line).append("\n");
                }
            } catch (IOException e) {
                System.out.println("Error reading file: " + e.getMessage());
                return;
            }
    
            // Check if file is empty
            if (sourceCode.toString().trim().isEmpty()) {
                System.out.println(" Error: The file is empty.");
                return;
            }
    
            // Tokenize the content
            LexicalAnalyzer lexer = new LexicalAnalyzer();
            List<LexicalAnalyzer.Token> tokens = lexer.tokenize(sourceCode.toString());
    
            // Print Tokens
            System.out.println("\n🔹 Tokenized Output:");
            for (LexicalAnalyzer.Token token : tokens) {
                System.out.println(token);
            }
    
            // Print Symbol Table
            lexer.printSymbolTable();
        }
    
            
        public static void main(String[] args) {
        String filePath = "sample.zaplag"; // Replace with your actual file path

        try {
            // Read the source code from the file
            String sourceCode = new String(Files.readAllBytes(Paths.get(filePath)));

            // Process the .mylanguage file
            processFile(filePath);

            // NFA Construction
            System.out.println("\n🔹 NFA Construction for variable names:");
            NFA nfa = new NFA().constructFromRegex("[a-z]+");
            nfa.printNFA();

            // Convert NFA to DFA
            DFA dfa = new DFA().constructFromNFA(nfa);
            dfa.printDFA();

            // Lexical Analysis and Symbol Table Processing
            LexicalAnalyzer lexer = new LexicalAnalyzer();
            List<LexicalAnalyzer.Token> tokens = lexer.tokenize(sourceCode);

            // Print Tokens
            System.out.println("\n🔹 Tokens:");
            for (LexicalAnalyzer.Token token : tokens) {
                System.out.println(token);
            }

            // Print Symbol Table
            lexer.printSymbolTable();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    }
    